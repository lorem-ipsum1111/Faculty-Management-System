<html>
<body>

<h1>Home</h1>

</body>
</html>

<?php

echo '<a href="http://localhost/LeavePortal/LoginPortal.php">Login for application and other privilages</a>';
echo "<br>";
echo '<a href="http://localhost/phpmongodb/HomePage.php">To see MongoDB Part</a>';
echo "<br>";
?>