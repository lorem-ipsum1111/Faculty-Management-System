<?php
    echo "Welcome dear Admin!!! <br>";
    
    //Replenish Leaves : Function to replenish
    /*Change Leave Application Route 
        -> shows current path in order
        -> ne

    */
    
    //Change POR
    //Change HOD
    //See the Leave-Log-PaperWork Table

    
echo '<a href="http://localhost/LeavePortal/RegisterNormalFaculty.php">New Normal Faculty</a>';
echo "<br>";
echo '<a href="http://localhost/LeavePortal/RegisterCrossCuttingFaculty.php">New Cross Cutting Faculty</a>';
echo "<br>";
echo '<a href="http://localhost/LeavePortal/ReplenishLeaves.php">To replenish leaves</a>';
echo "<br>";
echo '<a href="http://localhost/LeavePortal/DeptForChangeHOD.php">Change HOD</a>';
echo "<br>";
echo '<a href="http://localhost/LeavePortal/FacId&DesForChangePOR.php">Change POR</a>'; 
echo "<br>";
echo '<a href="http://localhost/LeavePortal/FacIdForFire.php">Fire A Faculty</a>';
echo "<br>";
echo '<a href="http://localhost/LeavePortal/NormalFacIdToCrossCutting.php">Convert Normal Faculty to Cross Cutting</a>';
echo "<br>";
echo '<a href="http://localhost/LeavePortal/CrossCuttingFacIdToNormal.php">Convert Cross Cutting Faculty to Normal Faculty</a>';
echo "<br>";
echo '<a href="http://localhost/LeavePortal/AddOrEditPath.php">Add Or Edit Apllication Path</a>';
echo "<br>";
echo '<a href="http://localhost/LeavePortal/PaperTrails.php">Paper Trail of Leave Applications</a>';
echo "<br>";
echo '<a href="http://localhost/LeavePortal/DecisionsTrail.php">Paper Trail  of Project Applications</a>';
echo "<br>";
echo '<a href="http://localhost/LeavePortal/Home.php">Home</a>';
echo "<br>";
echo "<button><a href ='logout.php'>Logout</a></button>";

?>

