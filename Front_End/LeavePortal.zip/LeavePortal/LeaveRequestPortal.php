<html>
<body>

<h1>Enter your comments (Reasons for leave) and Leave Date</h1>
<form action="LeaveRequestInitiate.php" method="post">
<b>Comments : <b> <input type="text" name="comments">
<b>Dates : <b> <input type="date" name="from_date">
<b> - <b> <input type="date" name="till_date">
<br>
<input type="submit" value="submit">
</form>

</body>
</html>

