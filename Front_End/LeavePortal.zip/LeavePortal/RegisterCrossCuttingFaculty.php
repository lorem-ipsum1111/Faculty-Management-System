<html>
<body>

<h1>Info</h1>
<form action="NewCrossCuttingFacultyData.php" method="post">
<b>First Name : <b> <input type="text" name="first_name">
<b>Last Name : <b> <input type="text" name="last_name">
<b>Gender : <b> <input type="text" name="gender">
<b>Designation : <b> <input type="text" name="designation">
<b>Username : <b> <input type="text" name="username">
<b>Password : <b> <input type="password" name="password">

<br>
<input type="submit">
</form>

</body>
</html>