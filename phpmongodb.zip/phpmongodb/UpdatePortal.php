<html>
<body>

<h1>Update Info</h1>
<form method="post" action="UpdateAccountDetails.php">
<b>First Name : <b> <input type="text" name="new_firstname"><br>
<b>Second Name : <b> <input type="text" name="new_secondname"><br>
<b>DOB(DD/MM/YY) : <b> <input type="text" name="new_dob"><br>
<b>Username : <b> <input type="text" name="new_username"><br>
<b>Password : <b> <input type="password" name="new_password"><br>
<b>E-mail : <b> <input type="text" name="new_email"><br>
<b>Ph. No. : <b> <input type="text" name="new_ph_no"><br>
<b>Publications : <b> <input type="text" name="new_pub"><br>
<b>Grants : <b> <input type="text" name="new_grants"><br>
<b>Biography : <b> <input type="text" name="new_bio"><br>
<br>
<input type="submit">
</form>

</body>
</html>