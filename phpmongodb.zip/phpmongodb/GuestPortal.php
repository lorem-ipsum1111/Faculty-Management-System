<?php

echo "<br>";    
echo '<a href="http://localhost/phpmongodb/UsersList.php">See Other Users info</a>';

?>